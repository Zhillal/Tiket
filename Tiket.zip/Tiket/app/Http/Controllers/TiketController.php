<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\DB;

use Illuminate\Http\Request;

class TiketController extends Controller
{
    public function readdata()
    {
        //mau ambil data dari tabel mahasiswa
        $tiket= DB::table('tiket')->get();

        // mengirim ke halaman mahasiswa untuk ditampilkan data
        return view('daftartiket',['tiket'=>$tiket]);
    }

    public function input()
    {
        return view('jualtiket');
    }

    public function store(Request $request)
    {
        //memasukkan data kedalam databse
        DB::table('tiket')->insert([
            'Nama' => $request->nama,
            'Harga' => $request->harga,
            'Jumlah' => $request->jumlah,
            'Email' => $request->email,
        ]);

        return redirect('/daftartiket');
    }

    public function edit($harga)
    {
        #ambil data mahasiswa berdasarkan nim
        $tiket = DB::table('tiket')->where('Harga', $harga)->get();

        #passing data
        return view('edit', ['tiket' => $tiket]);
    }

    public function update(Request $request)
    {
        DB::table('tiket')->where('Harga', $request->harga)->update([
            'Nama' => $request->nama,
            'Harga' => $request->harga,
            'Jumlah' => $request->jumlah,
            'Email' => $request->email,
        ]);

        return redirect('/daftartiket');
    }

    public function hapus($harga)
    {
        DB::table('tiket')->where('Harga', $harga)->delete();
        return redirect('/daftartiket');
    }
}