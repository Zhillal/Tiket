
<?php $__env->startSection('title', 'Input Data Tiket'); ?>

<?php $__env->startSection('konten'); ?>
<div class="container">
    <h3>Isi informasi tiket yang ingin dijual</h3>
    <p>harga tidak bisa diubah setelah disubmit, tolong di buat dengan benar</p>
    <form action="/jualtiket/store" method ="get">
        <?php echo e(csrf_field()); ?>

        Nama Tiket <br>  <input type=text, name="nama", required="required"><br>
        Harga <br> <input type=text, name="harga", required="required"><br>
        Jumlah <br><input type=text, name="jumlah", required="required"><br>
        Email <br><input type=text, name="email", required="required"><br>
        <input type="submit" value="Simpan Data">
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TugasKuliah\SEMESTER_4\PBW\Tiket\Tiket\resources\views/jualtiket.blade.php ENDPATH**/ ?>