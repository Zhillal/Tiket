
<?php $__env->startSection('title', 'Data Tiket'); ?>

<?php $__env->startSection('konten'); ?>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
<script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>

<div class="container">
    <h2> Tiket yang dijual </h2>
    <p>Hubungi email pemilik tiket untuk melakukan pembelian</p>
	<div class="row">
        <div class="table-responsive">                
            <table id="mytable" class="table table-bordred table-striped">
                <thead>
                    <th>Nama</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Email</th>
                </thead>
            <tbody> 
                <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($tkt->Nama); ?></td>
                    <td><?php echo e($tkt->Harga); ?></td>
                    <td><?php echo e($tkt->Jumlah); ?></td>
                    <td><?php echo e($tkt->Email); ?></td>
                    <td>
                        <a href="/tiket/edit/<?php echo e($tkt->Harga); ?>">Edit</a>
                        <!-- <a href="">Edit</a>&nbsp;&nbsp;&nbsp; -->
                        <a style="color:red;" href="/tiket/hapus/<?php echo e($tkt->Harga); ?>">Hapus</a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TugasKuliah\SEMESTER_4\PBW\Tiket\Tiket\resources\views/daftartiket.blade.php ENDPATH**/ ?>