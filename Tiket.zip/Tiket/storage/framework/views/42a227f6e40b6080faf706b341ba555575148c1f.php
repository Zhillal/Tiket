
<?php $__env->startSection('title', 'Edit Data Tiket'); ?>

<?php $__env->startSection('konten'); ?>
    <?php $__currentLoopData = $tiket; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tkt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <form action="/tiket/update" method ="get">
            <?php echo e(csrf_field()); ?>

            Nama<br>  <input type=text, name="nama", required="required", value="<?php echo e($tkt->Nama); ?>"><br>
            Harga<br> <input type=text, name="harga", required="required", value="<?php echo e($tkt->Harga); ?>"><br>
            Jumlah <br><input type=text, name="jumlah", required="required", value="<?php echo e($tkt->Jumlah); ?>"><br>
            Email <br> <input type=text, name="email", required="required", value="<?php echo e($tkt->Email); ?>"><br>
            <input type="submit" value="Simpan Data">
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TugasKuliah\SEMESTER_4\PBW\Tiket\Tiket\resources\views/edit.blade.php ENDPATH**/ ?>