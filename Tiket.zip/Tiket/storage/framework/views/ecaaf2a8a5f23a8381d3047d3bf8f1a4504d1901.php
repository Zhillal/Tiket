
<?php $__env->startSection('title', 'Input Data Tiket'); ?>

<?php $__env->startSection('konten'); ?>
    <form action="/jualtiket" method ="get">
        <?php echo e(csrf_field()); ?>

        Nama Tiket <br>  <input type=text, name="nama", required="required"><br>
        Harga <br> <input type=text, name="harga", required="required"><br>
        Jumlah <br><input type=text, name="jumlah", required="required"><br>
        <input type="submit" value="Simpan Data">
    </form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\TugasKuliah\SEMESTER_4\PBW\Tiket\Tiket\resources\views/inputdata.blade.php ENDPATH**/ ?>