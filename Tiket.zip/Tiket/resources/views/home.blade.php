@extends('template')

@section('konten')
    <h2>Selamat Datang di Carlan Ticket Emporium</h2>
    <p>Carlan Ticket Emporium adalah website menjual tiket-tiket film terbaru, konser dan lain-lainnya</p>
    <p>Cek tab lihat Tiket untuk melihat daftar tiket yang terjual</p>
    <p>Ingin menjual tiket? Tekan jual tiket untuk mejual tiket yang anda ingin jual</p>
@endsection