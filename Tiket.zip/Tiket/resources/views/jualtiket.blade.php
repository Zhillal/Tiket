@extends('template')
@section('title', 'Input Data Tiket')

@section('konten')
<div class="container">
    <h3>Isi informasi tiket yang ingin dijual</h3>
    <p>harga tidak bisa diubah setelah disubmit, tolong di buat dengan benar</p>
    <form action="/jualtiket/store" method ="get">
        {{csrf_field()}}
        Nama Tiket <br>  <input type=text, name="nama", required="required"><br>
        Harga <br> <input type=text, name="harga", required="required"><br>
        Jumlah <br><input type=text, name="jumlah", required="required"><br>
        Email <br><input type=text, name="email", required="required"><br>
        <input type="submit" value="Simpan Data">
    </form>
</div>
@endsection