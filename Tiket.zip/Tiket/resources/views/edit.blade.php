@extends('template')
@section('title', 'Edit Data Tiket')

@section('konten')
    @foreach($tiket as $tkt)
        <form action="/tiket/update" method ="get">
            {{csrf_field()}}
            Nama<br>  <input type=text, name="nama", required="required", value="{{$tkt->Nama}}"><br>
            Harga<br> <input type=text, name="harga", required="required", value="{{$tkt->Harga}}"><br>
            Jumlah <br><input type=text, name="jumlah", required="required", value="{{$tkt->Jumlah}}"><br>
            Email <br> <input type=text, name="email", required="required", value="{{$tkt->Email}}"><br>
            <input type="submit" value="Simpan Data">
        </form>
    @endforeach
@endsection