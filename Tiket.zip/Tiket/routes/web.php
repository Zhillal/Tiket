<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\TiketController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('home');
});

Route::get('/daftartiket', [TiketController::class, 'readdata']);
Route::get('/jualtiket', [TiketController::class, 'input']);
Route::get('/jualtiket/store', [TiketController::class, 'store']);

Route::get('/tiket/edit/{Harga}', [TiketController::class, 'edit']);
Route::get('/tiket/update', [TiketController::class, 'update']);
Route::get('/tiket/hapus/{Harga}', [TiketController::class, 'hapus']);